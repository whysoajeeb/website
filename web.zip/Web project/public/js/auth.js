// Client-side JavaScript for authentication

document.addEventListener("DOMContentLoaded", () => {
    // Login form
    const loginForm = document.getElementById("login-form")
    if (loginForm) {
      loginForm.addEventListener("submit", async (e) => {
        e.preventDefault()
  
        const email = document.getElementById("email").value
        const password = document.getElementById("password").value
  
        try {
          const response = await fetch("/api/auth/login", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }),
          })
  
          const data = await response.json()
  
          if (response.ok) {
            // Save token to localStorage
            localStorage.setItem("token", data.token)
  
            // Transfer cart if there's a session cart
            const sessionId = getSessionId()
            if (sessionId) {
              await transferCart(data.token, sessionId)
            }
  
            // Redirect to checkout or home page
            const redirectUrl = new URLSearchParams(window.location.search).get("redirect") || "/"
            window.location.href = redirectUrl
          } else {
            // Show error message
            showError(data.message)
          }
        } catch (error) {
          console.error("Login error:", error)
          showError("An error occurred. Please try again.")
        }
      })
    }
  
    // Registration form
    const registerForm = document.getElementById("register-form")
    if (registerForm) {
      registerForm.addEventListener("submit", async (e) => {
        e.preventDefault()
  
        const name = document.getElementById("name").value
        const email = document.getElementById("email").value
        const password = document.getElementById("password").value
  
        try {
          const response = await fetch("/api/auth/register", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ name, email, password }),
          })
  
          const data = await response.json()
  
          if (response.ok) {
            // Save token to localStorage
            localStorage.setItem("token", data.token)
  
            // Redirect to login page or profile completion
            window.location.href = "/profile?new=true"
          } else {
            // Show error message
            showError(data.message)
          }
        } catch (error) {
          console.error("Registration error:", error)
          showError("An error occurred. Please try again.")
        }
      })
    }
  
    // Logout functionality
    const logoutButton = document.getElementById("logout-button")
    if (logoutButton) {
      logoutButton.addEventListener("click", async (e) => {
        e.preventDefault()
  
        try {
          await fetch("/api/auth/logout", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          })
  
          // Clear token from localStorage
          localStorage.removeItem("token")
  
          // Redirect to home page
          window.location.href = "/"
        } catch (error) {
          console.error("Logout error:", error)
        }
      })
    }
  
    // Helper functions
    function showError(message) {
      const errorElement = document.querySelector(".error-message")
      if (errorElement) {
        errorElement.textContent = message
        errorElement.style.display = "block"
      } else {
        alert(message)
      }
    }
  
    function getSessionId() {
      // Get session ID from cookie
      const cookies = document.cookie.split(";")
      for (const cookie of cookies) {
        const [name, value] = cookie.trim().split("=")
        if (name === "connect.sid") {
          return value
        }
      }
      return null
    }
  
    async function transferCart(token, sessionId) {
      try {
        await fetch("/api/cart/transfer", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ sessionId }),
        })
      } catch (error) {
        console.error("Error transferring cart:", error)
      }
    }
  
    // Check if user is logged in
    function checkAuth() {
      const token = localStorage.getItem("token")
      const authLinks = document.querySelectorAll(".auth-link")
      const profileLinks = document.querySelectorAll(".profile-link")
  
      if (token) {
        // User is logged in
        authLinks.forEach((link) => (link.style.display = "none"))
        profileLinks.forEach((link) => (link.style.display = "block"))
      } else {
        // User is not logged in
        authLinks.forEach((link) => (link.style.display = "block"))
        profileLinks.forEach((link) => (link.style.display = "none"))
      }
    }
  
    checkAuth()
  })
  