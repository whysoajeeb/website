// Client-side JavaScript for checkout process

document.addEventListener("DOMContentLoaded", () => {
    const checkoutForm = document.getElementById("checkout-form")
  
    if (checkoutForm) {
      checkoutForm.addEventListener("submit", async (e) => {
        e.preventDefault()
  
        // Get form data
        const formData = new FormData(checkoutForm)
        const shippingAddress = {
          street: formData.get("street"),
          city: formData.get("city"),
          state: formData.get("state"),
          zipCode: formData.get("zipCode"),
          country: formData.get("country"),
        }
        const paymentMethod = formData.get("paymentMethod")
  
        try {
          const response = await fetch("/api/orders", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
            body: JSON.stringify({
              shippingAddress,
              paymentMethod,
            }),
          })
  
          const data = await response.json()
  
          if (response.ok) {
            // Redirect to order confirmation page
            window.location.href = `/order-confirmation?id=${data.order._id}`
          } else {
            // Show error message
            showError(data.message)
          }
        } catch (error) {
          console.error("Checkout error:", error)
          showError("An error occurred. Please try again.")
        }
      })
    }
  
    // Load cart items in checkout page
    async function loadCartItems() {
      const cartItemsContainer = document.getElementById("cart-items")
      if (!cartItemsContainer) return
  
      try {
        const response = await fetch("/api/cart", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
  
        const cart = await response.json()
  
        if (cart.items.length === 0) {
          // Redirect to cart page if cart is empty
          window.location.href = "/cart"
          return
        }
  
        // Display cart items
        cartItemsContainer.innerHTML = ""
  
        cart.items.forEach((item) => {
          const itemElement = document.createElement("div")
          itemElement.className = "cart-item"
          itemElement.innerHTML = `
            <div class="item-details">
              <h4>${item.product.name}</h4>
              <p>Quantity: ${item.quantity}</p>
              <p>Price: $${item.price.toFixed(2)}</p>
              <p>Subtotal: $${(item.price * item.quantity).toFixed(2)}</p>
            </div>
          `
          cartItemsContainer.appendChild(itemElement)
        })
  
        // Display total
        const totalElement = document.getElementById("cart-total")
        if (totalElement) {
          totalElement.textContent = `$${cart.total.toFixed(2)}`
        }
      } catch (error) {
        console.error("Error loading cart items:", error)
        showError("Failed to load cart items. Please try again.")
      }
    }
  
    function showError(message) {
      const errorElement = document.querySelector(".error-message")
      if (errorElement) {
        errorElement.textContent = message
        errorElement.style.display = "block"
      } else {
        alert(message)
      }
    }
  
    // Load cart items if on checkout page
    if (window.location.pathname === "/checkout") {
      loadCartItems()
    }
  })
  