// Client-side JavaScript for cart functionality

document.addEventListener("DOMContentLoaded", () => {
    // Add to cart buttons
    const addToCartButtons = document.querySelectorAll(".add-to-cart")
  
    addToCartButtons.forEach((button) => {
      button.addEventListener("click", async (e) => {
        e.preventDefault()
  
        const productId = button.getAttribute("data-product-id")
        const quantity = Number.parseInt(button.getAttribute("data-quantity") || "1")
  
        try {
          const response = await fetch("/api/cart/add", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
            body: JSON.stringify({ productId, quantity }),
          })
  
          const data = await response.json()
  
          if (data.redirect) {
            // User is not logged in, redirect to login page
            window.location.href = data.redirect
          } else {
            // Show success message
            alert("Item added to cart!")
            updateCartCount(data.cart.items.length)
          }
        } catch (error) {
          console.error("Error adding to cart:", error)
          alert("Failed to add item to cart. Please try again.")
        }
      })
    })
  
    // Update cart count in the header
    function updateCartCount(count) {
      const cartCountElement = document.querySelector(".cart-count")
      if (cartCountElement) {
        cartCountElement.textContent = count.toString()
      }
    }
  
    // Load cart count on page load
    async function loadCartCount() {
      try {
        const response = await fetch("/api/cart", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
  
        const data = await response.json()
        updateCartCount(data.items.length)
      } catch (error) {
        console.error("Error loading cart:", error)
      }
    }
  
    loadCartCount()
  })
  