// Sample product data
const products = [
    {
        id: 1,
        name: "Smartphone X",
        price: 599.99,
        category: "Electronics",
        image: "iphonex.webp",
        rating: 4.5,
        inStock: true
    },
    {
        id: 2,
        name: "Laptop Pro",
        price: 1299.99,
        category: "Electronics",
        image: "laptop.jpeg",
        rating: 4.8,
        inStock: true
    },
    {
        id: 3,
        name: "Men's T-Shirt",
        price: 24.99,
        category: "Clothing",
        image: "tshirt.jpg",
        rating: 4.2,
        inStock: true
    },
    {
        id: 4,
        name: "Women's Dress",
        price: 49.99,
        category: "Clothing",
        image: "wo.avif",
        rating: 4.6,
        inStock: false
    },
    {
        id: 5,
        name: "Coffee Maker",
        price: 89.99,
        category: "Home & Kitchen",
        image: "co.jpeg",
        rating: 4.3,
        inStock: true
    },
    {
        id: 6,
        name: "Blender",
        price: 39.99,
        category: "Home & Kitchen",
        image: "pb.webp",
        rating: 4.1,
        inStock: true
    },
    {
        id: 7,
        name: "Face Cream",
        price: 19.99,
        category: "Beauty & Personal Care",
        image: "po.avif",
        rating: 4.4,
        inStock: true
    },
    {
        id: 8,
        name: "Organic Tea",
        price: 9.99,
        category: "Groceries",
        image: "or.jpeg",
        rating: 4.7,
        inStock: true
    }
];

// Function to display products
function displayProducts(productsArray, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = '';
    
    productsArray.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'col-md-3 col-sm-6';
        
        // Create stars based on rating
        let stars = '';
        const fullStars = Math.floor(product.rating);
        const halfStar = product.rating % 1 >= 0.5;
        
        for (let i = 1; i <= 5; i++) {
            if (i <= fullStars) {
                stars += '<i class="fas fa-star"></i>';
            } else if (halfStar && i === fullStars + 1) {
                stars += '<i class="fas fa-star-half-alt"></i>';
            } else {
                stars += '<i class="far fa-star"></i>';
            }
        }
        
        // Stock badge
        const stockBadge = product.inStock 
            ? '<span class="badge bg-success">In Stock</span>' 
            : '<span class="badge bg-danger">Out of Stock</span>';
        
        productCard.innerHTML = `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-img">
                <div class="product-body">
                    <h5 class="product-title">${product.name}</h5>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    <div class="product-rating">${stars}</div>
                    <div class="d-flex justify-content-between align-items-center">
                        ${stockBadge}
                        <button class="btn btn-primary btn-sm add-to-cart" data-id="${product.id}">
                            <i class="fas fa-shopping-cart me-1"></i>Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        container.appendChild(productCard);
    });
    
    // Add event listeners to the Add to Cart buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const productId = this.getAttribute('data-id');
            addToCart(productId);
            e.preventDefault();
        });
    });
}

// Function to add product to cart
function addToCart(productId) {
    // Get the product
    const product = products.find(p => p.id == productId);
    if (!product) return;
    
    // Show notification
    alert(`${product.name} added to cart!`);
    
    // In a real application, you would store the cart in localStorage or send to a server
    console.log(`Added to cart: ${product.name}`);
}

// Function to filter products
function filterProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const categoryFilter = document.getElementById('categoryFilter').value;
    const sortFilter = document.getElementById('sortFilter').value;
    
    // Filter by search term and category
    let filteredProducts = products.filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm);
        const matchesCategory = categoryFilter === 'All Categories' || product.category === categoryFilter;
        return matchesSearch && matchesCategory;
    });
    
    // Sort products
    if (sortFilter === 'Price: Low to High') {
        filteredProducts.sort((a, b) => a.price - b.price);
    } else if (sortFilter === 'Price: High to Low') {
        filteredProducts.sort((a, b) => b.price - a.price);
    } else if (sortFilter === 'Popularity') {
        filteredProducts.sort((a, b) => b.rating - a.rating);
    }
    
    // Display filtered products
    displayProducts(filteredProducts, 'featuredProducts');
}

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    // Display featured products
    displayProducts(products, 'featuredProducts');
    
    // Add event listeners for filtering
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const sortFilter = document.getElementById('sortFilter');
    
    if (searchInput) {
        searchInput.addEventListener('input', filterProducts);
    }
    
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterProducts);
    }
    
    if (sortFilter) {
        sortFilter.addEventListener('change', filterProducts);
    }
    
    // Initialize Bootstrap tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});