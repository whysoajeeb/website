import jwt from "jsonwebtoken"

// Generate JWT token
export const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET || "pakmart-jwt-secret", { expiresIn: "7d" })
}

// Middleware to verify JWT token
export const verifyToken = (req, res, next) => {
  // Get token from header
  const token = req.header("Authorization")?.replace("Bearer ", "")

  // Check if no token
  if (!token) {
    return res.status(401).json({ message: "No token, authorization denied" })
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "pakmart-jwt-secret")

    // Add user ID to request
    req.userId = decoded.userId
    next()
  } catch (error) {
    res.status(401).json({ message: "Token is not valid" })
  }
}

// Middleware for optional authentication
export const optionalAuth = (req, res, next) => {
  // Get token from header
  const token = req.header("Authorization")?.replace("Bearer ", "")

  if (token) {
    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || "pakmart-jwt-secret")

      // Add user ID to request
      req.userId = decoded.userId
    } catch (error) {
      // Invalid token, but continue without authentication
      console.error("Invalid token:", error)
    }
  }

  next()
}
