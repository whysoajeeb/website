import express from "express"
import mongoose from "mongoose"
import dotenv from "dotenv"
import cors from "cors"
import session from "express-session"
import cookieParser from "cookie-parser"
import path from "path"
import { fileURLToPath } from "url"
import fs from "fs" // Import the 'fs' module

// Import routes
import authRoutes from "./routes/auth.js"
import cartRoutes from "./routes/cart.js"
import orderRoutes from "./routes/order.js"

// Configure environment variables
dotenv.config()

// Create Express app
const app = express()
const PORT = process.env.PORT || 5000

// Get current directory
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Middleware
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(
  cors({
    origin: "http://localhost:5000",
    credentials: true,
  }),
)
app.use(cookieParser())
app.use(
  session({
    secret: process.env.SESSION_SECRET || "pak-mart-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 }, // 24 hours
  }),
)

// Serve static files
app.use(express.static(path.join(__dirname, "my project of web")))

// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost:27017/pakmart")
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err))

// Routes
app.use("/api/auth", authRoutes)
app.use("/api/cart", cartRoutes)
app.use("/api/orders", orderRoutes)

// Serve HTML files
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "my project of web", "index.html"))
})

// Handle all other routes - redirect to frontend routes
app.get("*", (req, res) => {
  // Check if the requested path exists as an HTML file
  const requestedPage = `${req.path.substring(1)}.html`
  const filePath = path.join(__dirname, "my project of web", requestedPage)

  try {
    if (fs.existsSync(filePath)) {
      return res.sendFile(filePath)
    }
    // If file doesn't exist, send the index.html
    res.sendFile(path.join(__dirname, "my project of web", "index.html"))
  } catch (err) {
    res.sendFile(path.join(__dirname, "my project of web", "index.html"))
  }
})

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
