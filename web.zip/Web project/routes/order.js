import express from "express"
import Order from "../models/Order.js"
import Cart from "../models/Cart.js"
import User from "../models/User.js"
import { verifyToken } from "../utils/auth.js"

const router = express.Router()

// Create a new order
router.post("/", verifyToken, async (req, res) => {
  try {
    const { shippingAddress, paymentMethod } = req.body

    // Validate required fields
    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({ message: "Shipping address and payment method are required" })
    }

    // Find user's cart
    const cart = await Cart.findOne({ user: req.userId }).populate("items.product")

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" })
    }

    // Get user info
    const user = await User.findById(req.userId)

    if (!user) {
      return res.status(404).json({ message: "User not found" })
    }

    // Create order items from cart items
    const orderItems = cart.items.map((item) => ({
      product: item.product._id,
      name: item.product.name,
      quantity: item.quantity,
      price: item.price,
    }))

    // Create new order
    const order = new Order({
      user: req.userId,
      items: orderItems,
      total: cart.total,
      shippingAddress: {
        name: user.name,
        ...shippingAddress,
      },
      paymentMethod,
    })

    await order.save()

    // Clear the cart after order is created
    cart.items = []
    await cart.save()

    res.status(201).json({
      message: "Order created successfully",
      order,
    })
  } catch (error) {
    console.error("Create order error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get all orders for the current user
router.get("/", verifyToken, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.userId }).sort({ createdAt: -1 })

    res.json(orders)
  } catch (error) {
    console.error("Get orders error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Get a specific order by ID
router.get("/:orderId", verifyToken, async (req, res) => {
  try {
    const order = await Order.findOne({
      _id: req.params.orderId,
      user: req.userId,
    }).populate("items.product")

    if (!order) {
      return res.status(404).json({ message: "Order not found" })
    }

    res.json(order)
  } catch (error) {
    console.error("Get order error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Cancel an order
router.put("/:orderId/cancel", verifyToken, async (req, res) => {
  try {
    const order = await Order.findOne({
      _id: req.params.orderId,
      user: req.userId,
    })

    if (!order) {
      return res.status(404).json({ message: "Order not found" })
    }

    // Only allow cancellation if order is still processing
    if (order.orderStatus !== "processing") {
      return res.status(400).json({
        message: "Cannot cancel order that has been shipped or delivered",
      })
    }

    order.orderStatus = "cancelled"
    await order.save()

    res.json({
      message: "Order cancelled successfully",
      order,
    })
  } catch (error) {
    console.error("Cancel order error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
