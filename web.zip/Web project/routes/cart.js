import express from "express"
import Cart from "../models/Cart.js"
import Product from "../models/Product.js"
import { verifyToken, optionalAuth } from "../utils/auth.js"

const router = express.Router()

// Get cart (works for both logged in and non-logged in users)
router.get("/", optionalAuth, async (req, res) => {
  try {
    let cart

    if (req.userId) {
      // Logged in user - get cart by user ID
      cart = await Cart.findOne({ user: req.userId }).populate("items.product")
    } else if (req.session.sessionId) {
      // Non-logged in user - get cart by session ID
      cart = await Cart.findOne({ sessionId: req.session.sessionId }).populate("items.product")
    }

    if (!cart) {
      return res.json({ items: [], total: 0 })
    }

    res.json(cart)
  } catch (error) {
    console.error("Get cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Add item to cart
router.post("/add", optionalAuth, async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body

    // Find product
    const product = await Product.findById(productId)
    if (!product) {
      return res.status(404).json({ message: "Product not found" })
    }

    let cart

    if (req.userId) {
      // Logged in user - find or create cart by user ID
      cart = await Cart.findOne({ user: req.userId })
      if (!cart) {
        cart = new Cart({ user: req.userId, items: [] })
      }
    } else {
      // Non-logged in user - find or create cart by session ID
      if (!req.session.sessionId) {
        req.session.sessionId = Date.now().toString()
      }

      cart = await Cart.findOne({ sessionId: req.session.sessionId })
      if (!cart) {
        cart = new Cart({ sessionId: req.session.sessionId, items: [] })
      }
    }

    // Check if product already in cart
    const existingItemIndex = cart.items.findIndex((item) => item.product.toString() === productId)

    if (existingItemIndex > -1) {
      // Update quantity if product already in cart
      cart.items[existingItemIndex].quantity += quantity
    } else {
      // Add new item to cart
      cart.items.push({
        product: productId,
        quantity,
        price: product.price,
      })
    }

    await cart.save()

    // If user is not logged in, redirect to login page
    if (!req.userId) {
      return res.json({
        redirect: "/signin",
        message: "Please login to continue with your purchase",
        cart,
      })
    }

    res.json({
      message: "Item added to cart",
      cart,
    })
  } catch (error) {
    console.error("Add to cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Update cart item quantity
router.put("/update", optionalAuth, async (req, res) => {
  try {
    const { productId, quantity } = req.body

    let cart

    if (req.userId) {
      cart = await Cart.findOne({ user: req.userId })
    } else if (req.session.sessionId) {
      cart = await Cart.findOne({ sessionId: req.session.sessionId })
    }

    if (!cart) {
      return res.status(404).json({ message: "Cart not found" })
    }

    // Find item in cart
    const itemIndex = cart.items.findIndex((item) => item.product.toString() === productId)

    if (itemIndex === -1) {
      return res.status(404).json({ message: "Item not found in cart" })
    }

    if (quantity <= 0) {
      // Remove item if quantity is 0 or less
      cart.items.splice(itemIndex, 1)
    } else {
      // Update quantity
      cart.items[itemIndex].quantity = quantity
    }

    await cart.save()

    res.json({
      message: "Cart updated successfully",
      cart,
    })
  } catch (error) {
    console.error("Update cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Remove item from cart
router.delete("/remove/:productId", optionalAuth, async (req, res) => {
  try {
    const { productId } = req.params

    let cart

    if (req.userId) {
      cart = await Cart.findOne({ user: req.userId })
    } else if (req.session.sessionId) {
      cart = await Cart.findOne({ sessionId: req.session.sessionId })
    }

    if (!cart) {
      return res.status(404).json({ message: "Cart not found" })
    }

    // Remove item from cart
    cart.items = cart.items.filter((item) => item.product.toString() !== productId)

    await cart.save()

    res.json({
      message: "Item removed from cart",
      cart,
    })
  } catch (error) {
    console.error("Remove from cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Clear cart
router.delete("/clear", optionalAuth, async (req, res) => {
  try {
    let cart

    if (req.userId) {
      cart = await Cart.findOne({ user: req.userId })
    } else if (req.session.sessionId) {
      cart = await Cart.findOne({ sessionId: req.session.sessionId })
    }

    if (!cart) {
      return res.status(404).json({ message: "Cart not found" })
    }

    cart.items = []
    await cart.save()

    res.json({
      message: "Cart cleared successfully",
      cart,
    })
  } catch (error) {
    console.error("Clear cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Transfer cart from session to user after login
router.post("/transfer", verifyToken, async (req, res) => {
  try {
    const { sessionId } = req.body

    if (!sessionId) {
      return res.status(400).json({ message: "Session ID is required" })
    }

    // Find session cart
    const sessionCart = await Cart.findOne({ sessionId })

    if (!sessionCart || sessionCart.items.length === 0) {
      return res.json({ message: "No items to transfer" })
    }

    // Find or create user cart
    let userCart = await Cart.findOne({ user: req.userId })

    if (!userCart) {
      userCart = new Cart({ user: req.userId, items: [] })
    }

    // Merge items from session cart to user cart
    sessionCart.items.forEach((sessionItem) => {
      const existingItemIndex = userCart.items.findIndex(
        (item) => item.product.toString() === sessionItem.product.toString(),
      )

      if (existingItemIndex > -1) {
        userCart.items[existingItemIndex].quantity += sessionItem.quantity
      } else {
        userCart.items.push(sessionItem)
      }
    })

    await userCart.save()

    // Delete session cart
    await Cart.deleteOne({ sessionId })

    res.json({
      message: "Cart transferred successfully",
      cart: userCart,
    })
  } catch (error) {
    console.error("Transfer cart error:", error)
    res.status(500).json({ message: "Server error" })
  }
})

export default router
