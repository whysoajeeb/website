import mongoose from "mongoose"

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
    min: 0,
  },
  category: {
    type: String,
    required: true,
    enum: ["beauty", "clothing", "electronics", "groceries", "home-kitchen", "sports"],
  },
  imageUrl: String,
  inStock: {
    type: Boolean,
    default: true,
  },
  quantity: {
    type: Number,
    default: 1,
    min: 0,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

const Product = mongoose.model("Product", productSchema)

export default Product
